CREATE TRIGGER tr_entities_attr_data
    BEFORE INSERT
    ON entities_attr_data
BEGIN
    SELECT CASE
               WHEN NEW.ea_upload_date is null THEN
                       new.ea_upload_date = (DateTime('now'))
               END;
    SELECT CASE
               WHEN NEW.ea_modify_date is null THEN
                       new.ea_modify_date = (DateTime('now'))
               END;
END;

