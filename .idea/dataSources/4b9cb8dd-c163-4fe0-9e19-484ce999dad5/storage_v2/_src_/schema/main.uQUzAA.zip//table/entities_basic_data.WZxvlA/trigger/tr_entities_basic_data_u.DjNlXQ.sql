CREATE TRIGGER tr_entities_basic_data_u
    BEFORE update
    ON entities_basic_data
BEGIN
    SELECT CASE
               WHEN NEW.en_modify_date <> (DateTime('now')) THEN
                       new.en_modify_date = (DateTime('now'))
               END;
END;

