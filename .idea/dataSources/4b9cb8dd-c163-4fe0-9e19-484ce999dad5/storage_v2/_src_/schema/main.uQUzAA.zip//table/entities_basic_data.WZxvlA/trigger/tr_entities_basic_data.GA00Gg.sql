CREATE TRIGGER tr_entities_basic_data
    BEFORE INSERT
    ON entities_basic_data
BEGIN
    SELECT CASE
               WHEN NEW.en_upload_date is null THEN
                       new.en_upload_date = (DateTime('now'))
               END;
    SELECT CASE
               WHEN NEW.en_modify_date is null THEN
                       new.en_modify_date = (DateTime('now'))
               END;
END;

