CREATE TRIGGER tr_file_basic_data
    BEFORE INSERT ON file_basic_data
BEGIN
    SELECT
        CASE
            WHEN NEW.fl_upload_date is null THEN
                new.fl_upload_date = (DateTime('now'))
            END;
    SELECT
        CASE
            WHEN NEW.fl_modify_date is null THEN
                    new.fl_modify_date = (DateTime('now'))
            END;
END;

