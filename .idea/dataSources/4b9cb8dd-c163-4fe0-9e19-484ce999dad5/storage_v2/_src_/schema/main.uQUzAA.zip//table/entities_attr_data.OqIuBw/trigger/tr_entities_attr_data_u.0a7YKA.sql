CREATE TRIGGER tr_entities_attr_data_u
    BEFORE update
    ON entities_attr_data
BEGIN
    SELECT CASE
               WHEN NEW.ea_modify_date <> (DateTime('now')) THEN
                       new.ea_modify_date = (DateTime('now'))
               END;
END;

