CREATE TRIGGER tr_file_basic_data_u
    BEFORE update ON file_basic_data
BEGIN
    SELECT
        CASE
            WHEN NEW.fl_modify_date <> (DateTime('now')) THEN
                    new.fl_modify_date = (DateTime('now'))
            END;
END;

