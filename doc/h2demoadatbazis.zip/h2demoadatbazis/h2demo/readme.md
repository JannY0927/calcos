

https://www.baeldung.com/h2-embedded-db-data-storage
https://www.baeldung.com/spring-boot-h2-database
https://github.com/tadmacy/h2-filebased-db-example/tree/master/src